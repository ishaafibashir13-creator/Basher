
version = "1.26.2"
__version__ = version
full_version = version

git_revision = "884ec5f14591d69844e20c9dc6a6a9c5d1ba0a41"
release = 'dev' not in version and '+' not in version
short_version = version.split("+")[0]
